#ifndef  __TIM_H
#define  __TIM_H

extern uint32_t system_time;

extern void TIM5_Configuration(void);
extern uint32_t get_system_time(void);

#endif
